MOVING FORWARD — STUDENT WEBSITE PROTOTYPE

How to use:
1. Open index.html in a browser.
2. The site works without internet after it is opened.
3. Journal entries and routine checkmarks are stored locally in the browser using localStorage.
4. No account or server is required.

Project purpose:
This is a prototype for a STEM project about healthy coping and maintaining routines after a difficult relationship ending.

Important:
This is not a medical or mental-health treatment tool. It does not diagnose users or promise to make someone move on.
